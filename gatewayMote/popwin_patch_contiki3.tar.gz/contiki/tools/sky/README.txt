Contiki v 3.0 has wrong/bad serialdump-linux, this one is from v2.7 and works with sensors XM1000 and Z1
